<?php $__env->startSection('title', 'Leaderboard'); ?>

<?php $__env->startSection('content'); ?>
<?php $kelasUser = Auth::user()->kelas ?? 'VII'; ?>
<div class="filter-row" style="margin:0 0 10px">
    <a href="<?php echo e(request()->fullUrlWithQuery(['kelas' => $kelasUser])); ?>" class="chip <?php echo e($kelas === $kelasUser ? 'active' : ''); ?>">Kelas <?php echo e($kelasUser); ?></a>
    <a href="<?php echo e(request()->fullUrlWithQuery(['kelas' => ''])); ?>" class="chip <?php echo e($kelas === '' ? 'active' : ''); ?>">Seluruh sekolah</a>
</div>
<div class="page-sub" style="margin-bottom:20px">
    <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'refresh']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'refresh']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> Peringkat dihitung dari akumulasi total poin di riwayat kuis dan diperbarui real-time. Pencarian mufrodat tidak memengaruhi poin maupun peringkat.
</div>

<?php $top3 = $ranking->take(3); ?>
<?php if($top3->count() >= 2): ?>
<div class="podium-row">
    <?php
        $order = $top3->count() >= 3 ? [1, 0, 2] : [1, 0];
        $heights = [0 => 110, 1 => 80, 2 => 60];
        $colors = [0 => 'podium-gold', 1 => 'podium-silver', 2 => 'podium-bronze'];
    ?>
    <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(!isset($top3[$idx])) continue; ?>
        <?php $p = $top3[$idx]; ?>
        <div class="podium-col">
            <div class="avatar" style="width:44px;height:44px;font-size:15px;margin:0 auto 6px"><?php echo e(strtoupper(substr($p->name ?? 'U', 0, 2))); ?></div>
            <div style="font-size:12px;font-weight:600;color:var(--gray-900);text-align:center"><?php echo e(explode(' ', $p->name ?? 'Siswa')[0]); ?><?php echo e($p->id === Auth::id() ? ' (kamu)' : ''); ?></div>
            <div style="font-size:11px;color:var(--gray-400);text-align:center;margin-bottom:8px"><?php echo e(number_format($p->total_poin)); ?> poin</div>
            <div class="podium-block <?php echo e($colors[$idx]); ?>" style="height:<?php echo e($heights[$idx]); ?>px"><?php echo e($idx + 1); ?></div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>

<?php if($myRank): ?>
<div class="card" style="background:var(--green-light);border-color:#9BD1B3;margin-bottom:20px">
    <div class="btn-row" style="justify-content:space-between">
        <div>
            <div style="font-size:11px;color:var(--gray-500)">Posisi kamu</div>
            <div style="font-size:20px;font-weight:800;color:var(--green)">#<?php echo e($myRank->peringkat); ?></div>
        </div>
        <div style="text-align:right">
            <div style="font-size:11px;color:var(--gray-500)">Total poin</div>
            <div style="font-size:20px;font-weight:800;color:var(--green)"><?php echo e(number_format($myRank->total_poin)); ?></div>
        </div>
        <div style="text-align:right">
            <div style="font-size:11px;color:var(--gray-500)">Sesi kuis</div>
            <div style="font-size:20px;font-weight:800;color:var(--green)"><?php echo e($myRank->total_sesi); ?></div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php if($ranking->count() > 0): ?>
    <?php $__currentLoopData = $ranking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $isMe = $item->id === Auth::id();
        $inisial = strtoupper(substr($item->name ?? 'U', 0, 2));
    ?>
    <div class="lb-item <?php echo e($isMe ? 'me' : ($item->peringkat === 1 ? 'gold' : '')); ?>">
        <div class="rank <?php echo e($item->peringkat === 1 ? 'rank-1' : ($item->peringkat === 2 ? 'rank-2' : ($item->peringkat === 3 ? 'rank-3' : 'rank-n'))); ?>">
            <?php if($item->peringkat === 1): ?> <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'trophy','size' => '16']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'trophy','size' => '16']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
            <?php elseif($item->peringkat === 2): ?> <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'medal','size' => '16']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'medal','size' => '16']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
            <?php elseif($item->peringkat === 3): ?> <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'medal','size' => '16']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'medal','size' => '16']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
            <?php else: ?> <?php echo e($item->peringkat); ?>

            <?php endif; ?>
        </div>
        <div class="avatar"><?php echo e($inisial); ?></div>
        <div style="flex:1">
            <div style="font-size:14px;font-weight:600;color:var(--gray-900)">
                <?php echo e($item->name ?? 'Unknown'); ?>

                <?php if($isMe): ?><span class="pill pill-green" style="margin-left:6px">kamu</span><?php endif; ?>
            </div>
            <div style="font-size:11px;color:var(--gray-400)">Level <?php echo e($item->kelas ?? '-'); ?> · <?php echo e($item->total_sesi); ?> kuis selesai</div>
        </div>
        <div style="text-align:right">
            <div style="font-size:16px;font-weight:700;color:var(--green)"><?php echo e(number_format($item->total_poin)); ?></div>
            <div style="font-size:11px;color:var(--gray-400)">poin</div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<div style="text-align:center;padding:48px 0;color:var(--gray-400)">
    <div style="margin-bottom:8px"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'trophy','size' => '36']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'trophy','size' => '36']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?></div>
    <div style="font-size:14px">Belum ada data. Mulai kuis untuk masuk leaderboard!</div>
    <a href="/kuis" class="btn btn-primary" style="margin-top:14px;display:inline-flex">Mulai kuis</a>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-murfodat', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PBKK\mufrodat_ku\resources\views/leaderboard.blade.php ENDPATH**/ ?>