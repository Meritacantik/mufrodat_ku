<?php $__env->startSection('title', 'Data Siswa'); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
<div class="alert alert-success"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'check-circle','size' => '14']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'check-circle','size' => '14']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> <?php echo e(session('success')); ?></div>
<?php endif; ?>

<div style="text-align:right;margin-bottom:16px">
    <span style="font-size:12px;color:var(--gray-500)"><?php echo e($users->count()); ?> siswa terdaftar</span>
</div>

<form method="GET" class="btn-row" style="margin-bottom:16px">
    <input type="text" name="q" value="<?php echo e($search); ?>" placeholder="Cari siswa (nama/NIS)..." class="form-input" style="flex:1">
    <button type="submit" class="btn btn-primary">Cari</button>
</form>

<div class="card" style="padding:0">
    <table class="tbl">
        <thead>
            <tr><th>NIS</th><th>Nama</th><th>Kelas</th><th>Total poin</th><th>Kuis selesai</th><th>Aksi</th></tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td style="color:var(--gray-500)"><?php echo e($u->nis ?? '-'); ?></td>
                <td>
                    <div style="display:flex;align-items:center;gap:8px">
                        <div class="avatar"><?php echo e(strtoupper(substr($u->name, 0, 2))); ?></div>
                        <?php echo e($u->name); ?>

                    </div>
                </td>
                <td><span class="pill <?php echo e($u->kelas === 'VII' ? 'pill-green' : ($u->kelas === 'VIII' ? 'pill-blue' : 'pill-amber')); ?>"><?php echo e($u->kelas ?? '-'); ?></span></td>
                <td><b style="color:var(--green)"><?php echo e($u->score ? number_format($u->score->total_poin) : 0); ?></b></td>
                <td><?php echo e($u->score ? $u->score->total_sesi : 0); ?> kuis</td>
                <td>
                    <a href="/admin/users/edit/<?php echo e($u->id); ?>" title="Edit / Reset Password / Hapus"
                       style="width:28px;height:28px;display:inline-flex;align-items:center;justify-content:center;background:var(--gray-100);color:var(--gray-500);border-radius:6px">
                        <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'edit','size' => '14']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'edit','size' => '14']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                    </a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-murfodat', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PBKK\mufrodat_ku\resources\views/admin/users.blade.php ENDPATH**/ ?>