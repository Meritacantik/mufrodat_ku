<?php $__env->startSection('title', 'Kelola Mufrodat'); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('success')): ?>
<div class="alert alert-success"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'check-circle','size' => '14']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'check-circle','size' => '14']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> <?php echo e(session('success')); ?></div>
<?php endif; ?>

<form method="GET" action="/admin/mufrodat">
    <div class="btn-row" style="margin-bottom:16px;flex-wrap:wrap">
        <input type="text" name="q" value="<?php echo e($search); ?>" placeholder="Cari latin atau arti..." class="form-input" style="flex:1;min-width:160px">
        <select name="kelas" class="form-select" style="width:auto" onchange="this.form.submit()">
            <option value="">Semua kelas</option>
            <?php $__currentLoopData = ['VII','VIII','IX']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($k); ?>" <?php echo e($kelas === $k ? 'selected' : ''); ?>>Kelas <?php echo e($k); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <a href="/admin/mufrodat/tambah" class="btn btn-primary" style="white-space:nowrap">+ Tambah mufrodat</a>
    </div>
</form>

<div class="card responsive-table" style="padding:0">
    <table class="tbl">
        <thead>
            <tr style="background:var(--green-light)">
                <th>Kata Arab</th><th>Transliterasi</th><th>Arti</th><th>Bab</th><th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $mufrodat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td data-label="Kata Arab">
                    <div style="display:flex;align-items:center;justify-content:space-between;gap:8px">
                        <span style="direction:rtl;font-size:18px;flex:1"><?php echo e($m->arab); ?></span>
                        <button type="button"
                                onclick="<?php echo e($m->audio ? "new Audio('".asset('storage/'.$m->audio)."').play()" : "bacaKata(".json_encode($m->arab).")"); ?>"
                                title="Dengarkan pelafalan"
                                style="width:24px;height:24px;border-radius:50%;border:1px solid var(--gray-200);background:white;display:flex;align-items:center;justify-content:center;cursor:pointer;color:var(--green-dark);flex-shrink:0">
                            <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'volume','size' => '12']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'volume','size' => '12']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                        </button>
                    </div>
                </td>
                <td data-label="Transliterasi"><?php echo e($m->latin); ?></td>
                <td data-label="Arti">
                    <?php echo e($m->arti); ?>

                    <?php if($m->jenis): ?>
                    <div style="font-size:11px;color:var(--gray-400);margin-top:2px"><?php echo e($m->jenis); ?></div>
                    <?php endif; ?>
                </td>
                <td data-label="Bab">
                    <div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">
                        <span>Bab <?php echo e($m->bab); ?> - <?php echo e(config('bab_judul.'.$m->kelas.'.'.$m->bab)); ?></span>
                        <span class="pill <?php echo e($m->kelas === 'VII' ? 'pill-green' : ($m->kelas === 'VIII' ? 'pill-blue' : 'pill-amber')); ?>"><?php echo e($m->kelas); ?></span>
                    </div>
                </td>
                <td data-label="Aksi" style="white-space:nowrap">
                    <div class="btn-row" style="gap:6px;flex-wrap:nowrap">
                        <a href="/admin/mufrodat/edit/<?php echo e($m->id); ?>" title="Edit"
                           style="width:28px;height:28px;display:flex;align-items:center;justify-content:center;background:var(--green);color:white;border-radius:6px;text-decoration:none;flex-shrink:0">
                            <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'edit','size' => '14']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'edit','size' => '14']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                        </a>
                        <form method="POST" action="/admin/mufrodat/hapus/<?php echo e($m->id); ?>" onsubmit="return confirm('Hapus mufrodat ini?')">
                            <?php echo csrf_field(); ?>
                            <button type="submit" title="Hapus"
                                    style="width:28px;height:28px;display:flex;align-items:center;justify-content:center;background:var(--red);color:white;border-radius:6px;border:none;cursor:pointer;flex-shrink:0">
                                <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'x','size' => '14']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'x','size' => '14']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
                            </button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<div class="pagination"><?php echo e($mufrodat->withQueryString()->links('pagination.custom')); ?></div>

<script>
    function bacaKata(arab) {
        if ('speechSynthesis' in window) {
            window.speechSynthesis.cancel();
            let voices = window.speechSynthesis.getVoices();
            function speak() {
                voices = window.speechSynthesis.getVoices();
                const utterance = new SpeechSynthesisUtterance(arab);
                utterance.lang = 'ar-SA';
                utterance.rate = 0.7;
                const arabVoice = voices.find(v => v.lang.startsWith('ar'));
                if (arabVoice) utterance.voice = arabVoice;
                window.speechSynthesis.speak(utterance);
            }
            if (voices.length === 0) window.speechSynthesis.onvoiceschanged = speak;
            else speak();
        }
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-murfodat', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PBKK\mufrodat_ku\resources\views/admin/mufrodat/index.blade.php ENDPATH**/ ?>