<?php $__env->startSection('title', 'Kelola Sesi Kuis'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-sub" style="margin-bottom:16px">Bab / kategori kuis aktif, atur bab dan kelas yang bisa dikerjakan siswa</div>

<?php if(session('success')): ?>
<div class="alert alert-success"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'check-circle','size' => '14']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'check-circle','size' => '14']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> <?php echo e(session('success')); ?></div>
<?php endif; ?>

<div class="card" style="padding:0">
    <table class="tbl">
        <thead>
            <tr><th>Kelas</th><th>Bab</th><th>Jumlah Soal</th><th>Status</th><th>Aksi</th></tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $daftarBab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><span class="pill <?php echo e($b->kelas === 'VII' ? 'pill-green' : ($b->kelas === 'VIII' ? 'pill-blue' : 'pill-amber')); ?>"><?php echo e($b->kelas); ?></span></td>
                <td>Bab <?php echo e($b->bab); ?> - <?php echo e($b->judul); ?></td>
                <td><?php echo e($b->jumlah_soal); ?> soal</td>
                <td>
                    <?php if($b->status === 'aktif'): ?>
                    <span class="pill pill-green">Aktif</span>
                    <?php else: ?>
                    <span class="pill" style="background:var(--gray-200);color:var(--gray-600)">Draf</span>
                    <?php endif; ?>
                </td>
                <td>
                    <form method="POST" action="<?php echo e(route('admin.sesi-kuis.toggle', ['kelas' => $b->kelas, 'bab' => $b->bab])); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-secondary" style="padding:4px 12px;font-size:11px">Kelola</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-murfodat', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PBKK\mufrodat_ku\resources\views/admin/sesi-kuis.blade.php ENDPATH**/ ?>