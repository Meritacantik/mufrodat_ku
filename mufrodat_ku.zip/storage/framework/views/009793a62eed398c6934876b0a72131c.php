<?php $__env->startSection('title', 'Laporan Akurasi Sistem'); ?>

<?php $__env->startSection('content'); ?>
<div class="btn-row" style="justify-content:space-between">
    <div class="page-sub" style="margin-bottom:0">Evaluasi performa algoritma Levenshtein Distance (BAB II - 2.10 &amp; 2.11)</div>
    <a href="<?php echo e(route('admin.laporan.ekspor')); ?>" class="btn btn-secondary"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'download','size' => '14']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'download','size' => '14']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> Ekspor CSV</a>
</div>

<div class="stat-row" style="margin-top:16px">
    <div class="stat-c stat-white">
        <div class="stat-label">Siswa aktif</div>
        <div class="stat-val" style="color:var(--gray-900)"><?php echo e($siswaAktif); ?></div>
    </div>
    <div class="stat-c stat-green">
        <div class="stat-label">Kuis dikerjakan</div>
        <div class="stat-val"><?php echo e($kuisDikerjakan); ?></div>
    </div>
    <div class="stat-c stat-amber">
        <div class="stat-label">Rata-rata skor</div>
        <div class="stat-val"><?php echo e($rataRataSkor); ?>%</div>
    </div>
    <div class="stat-c stat-red">
        <div class="stat-label">Butuh perhatian</div>
        <div class="stat-val"><?php echo e($butuhPerhatian); ?> siswa</div>
    </div>
</div>

<div class="card" style="margin-bottom:20px">
    <form method="GET" class="btn-row" style="margin-bottom:14px">
        <input type="text" name="cari" value="<?php echo e($search); ?>" placeholder="Cari siswa atau bab..." class="form-input" style="flex:1">
        <button type="submit" class="btn btn-secondary">Cari</button>
    </form>
    <table class="tbl">
        <thead>
            <tr><th>Siswa</th><th>Bab</th><th>Skor</th><th>Waktu</th><th>Status</th></tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $sesiKuis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($s->user->name ?? '-'); ?></td>
                <td>Bab <?php echo e($s->bab); ?> - <?php echo e($s->judul_bab); ?></td>
                <td><?php echo e($s->skor_persen); ?>%</td>
                <td style="color:var(--gray-400);font-size:11px"><?php echo e($s->created_at->diffForHumans()); ?></td>
                <td>
                    <?php
                        $warnaStatus = ['Selesai' => 'pill-green', 'Belum selesai' => 'pill-amber', 'Perlu remedial' => 'pill-red'];
                    ?>
                    <span class="pill <?php echo e($warnaStatus[$s->status_laporan]); ?>"><?php echo e($s->status_laporan); ?></span>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="5" style="text-align:center;color:var(--gray-400)">Belum ada data sesi kuis</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<div style="margin:28px 0 4px">
    <div class="page-title" style="font-size:16px;margin-bottom:2px">Distribusi Hasil Kuis Siswa</div>
    <div class="page-sub" style="margin-bottom:0">Data real-time dari jawaban kuis yang sudah dikerjakan siswa (bukan pengujian algoritma)</div>
</div>

<div class="stat-row">
    <div class="stat-c stat-white">
        <div class="stat-label">Total jawaban kuis</div>
        <div class="stat-val" style="color:var(--gray-900)"><?php echo e($totalJawaban); ?></div>
        <div class="stat-sub">seluruh siswa</div>
    </div>
    <div class="stat-c stat-green">
        <div class="stat-label"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'check-circle','size' => '12']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'check-circle','size' => '12']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> BENAR</div>
        <div class="stat-val"><?php echo e($benar); ?></div>
    </div>
    <div class="stat-c stat-amber">
        <div class="stat-label"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'alert-triangle','size' => '12']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'alert-triangle','size' => '12']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> TYPO</div>
        <div class="stat-val"><?php echo e($typo); ?></div>
    </div>
    <div class="stat-c stat-red">
        <div class="stat-label"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'x-circle','size' => '12']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'x-circle','size' => '12']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> SALAH</div>
        <div class="stat-val"><?php echo e($salah); ?></div>
    </div>
</div>

<div class="card" style="margin-top:16px">
    <div class="card-title"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'chart-bar']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chart-bar']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> Persentase distribusi jawaban siswa</div>
    <?php if($totalJawaban > 0): ?>
        <?php $__currentLoopData = [['BENAR', $benar, 'var(--green)', 'fill-green'], ['TYPO', $typo, 'var(--amber)', 'fill-amber'], ['SALAH', $salah, 'var(--red)', 'fill-red']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $jml, $color, $fillClass]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="progress-wrap">
            <div class="progress-meta"><span style="color:<?php echo e($color); ?>"><?php echo e($label); ?></span><span><?php echo e(round(($jml/$totalJawaban)*100)); ?>%</span></div>
            <div class="progress-bar"><div class="progress-fill <?php echo e($fillClass); ?>" style="width:<?php echo e(round(($jml/$totalJawaban)*100)); ?>%"></div></div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <div style="text-align:center;color:var(--gray-400);padding:20px;font-size:13px">Belum ada data jawaban kuis</div>
    <?php endif; ?>
</div>

<div style="margin:32px 0 4px">
    <div class="page-title" style="font-size:16px;margin-bottom:2px">Evaluasi Akurasi Algoritma</div>
    <div class="page-sub" style="margin-bottom:0">
        Confusion matrix one-vs-rest terhadap <?php echo e($evaluasiAlgoritma['total']); ?> data uji variasi typo dengan ground truth diketahui (Bab III &amp; Bab II - 2.10/2.11)
    </div>
</div>

<div class="grid2">
    <div class="card">
        <div class="card-title"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'target']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'target']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> Metrik evaluasi algoritma (data uji)</div>
        <?php $__currentLoopData = [
            ['Accuracy', 'Klasifikasi tepat / Total data uji', $evaluasiAlgoritma['accuracy'], 'fill-green', 'var(--green)'],
            ['Precision', 'Macro-average TP/(TP+FP), 3 kelas', $evaluasiAlgoritma['precision'], 'fill-blue', 'var(--gray-700)'],
            ['Recall', 'Macro-average TP/(TP+FN), 3 kelas', $evaluasiAlgoritma['recall'], 'fill-amber', 'var(--amber)'],
            ['Error Rate', '1 - Accuracy', $evaluasiAlgoritma['error_rate'], 'fill-red', 'var(--red)'],
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $rumus, $nilai, $fillClass, $color]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="list-item" style="justify-content:space-between">
            <div style="flex:1">
                <div style="font-weight:600;font-size:13px"><?php echo e($label); ?></div>
                <div style="font-size:11px;color:var(--gray-400);margin-bottom:4px"><?php echo e($rumus); ?></div>
                <div class="progress-bar" style="width:140px"><div class="progress-fill <?php echo e($fillClass); ?>" style="width:<?php echo e($nilai); ?>%"></div></div>
            </div>
            <div style="font-size:20px;font-weight:800;color:<?php echo e($color); ?>"><?php echo e($nilai); ?>%</div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="alert <?php echo e($evaluasiAlgoritma['accuracy'] >= 80 ? 'alert-success' : 'alert-error'); ?>" style="margin-top:14px">
            <?php if($evaluasiAlgoritma['accuracy'] >= 80): ?>
                <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'check-circle','size' => '13']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'check-circle','size' => '13']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> Algoritma memenuhi target akurasi &ge; 80%
            <?php else: ?>
                <?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'alert-triangle','size' => '13']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'alert-triangle','size' => '13']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> Akurasi algoritma belum mencapai target 80%
            <?php endif; ?>
        </div>
    </div>

    <div class="card">
        <div class="card-title"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'grid']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'grid']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> Confusion matrix (baris = seharusnya, kolom = prediksi)</div>
        <table class="tbl">
            <thead>
                <tr><th>Aktual \ Prediksi</th><th style="text-align:center">BENAR</th><th style="text-align:center">TYPO</th><th style="text-align:center">SALAH</th></tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = ['BENAR','TYPO','SALAH']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aktual): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="font-weight:600"><?php echo e($aktual); ?></td>
                    <?php $__currentLoopData = ['BENAR','TYPO','SALAH']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prediksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td style="text-align:center; <?php echo e($aktual === $prediksi ? 'font-weight:800;color:var(--green)' : ''); ?>">
                        <?php echo e($evaluasiAlgoritma['confusion'][$aktual][$prediksi]); ?>

                    </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="card-title" style="margin-top:16px"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'ruler']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'ruler']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> Per kelas (one-vs-rest)</div>
        <table class="tbl">
            <thead>
                <tr><th>Kelas</th><th style="text-align:center">TP</th><th style="text-align:center">FP</th><th style="text-align:center">FN</th><th style="text-align:center">TN</th><th style="text-align:center">Precision</th><th style="text-align:center">Recall</th></tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $evaluasiAlgoritma['per_kelas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas => $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="font-weight:600"><?php echo e($kelas); ?></td>
                    <td style="text-align:center"><?php echo e($m['tp']); ?></td>
                    <td style="text-align:center"><?php echo e($m['fp']); ?></td>
                    <td style="text-align:center"><?php echo e($m['fn']); ?></td>
                    <td style="text-align:center"><?php echo e($m['tn']); ?></td>
                    <td style="text-align:center"><?php echo e($m['precision']); ?>%</td>
                    <td style="text-align:center"><?php echo e($m['recall']); ?>%</td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<?php $kasusMeleset = collect($evaluasiAlgoritma['detail'])->reject(fn($d) => $d['cocok']); ?>
<?php if($kasusMeleset->isNotEmpty()): ?>
<div class="card" style="margin-top:20px">
    <div class="card-title"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'alert-triangle']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'alert-triangle']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> Kasus data uji yang meleset dari ekspektasi (<?php echo e($kasusMeleset->count()); ?>)</div>
    <table class="tbl">
        <thead>
            <tr><th>Jawaban uji</th><th>Kata asli</th><th>Jenis variasi</th><th>Seharusnya</th><th>Prediksi sistem</th><th style="text-align:center">Jarak</th></tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $kasusMeleset; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($d['jawaban_uji']); ?></td>
                <td><?php echo e($d['kata_asli']); ?></td>
                <td><?php echo e($d['jenis_variasi']); ?></td>
                <td><span class="pill pill-green"><?php echo e($d['status_seharusnya']); ?></span></td>
                <td><span class="pill pill-red"><?php echo e($d['status_prediksi']); ?></span></td>
                <td style="text-align:center"><?php echo e($d['jarak']); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<div class="card" id="log-jawaban">
    <div class="card-title"><?php if (isset($component)) { $__componentOriginalce262628e3a8d44dc38fd1f3965181bc = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.icon','data' => ['name' => 'list']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'list']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $attributes = $__attributesOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__attributesOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc)): ?>
<?php $component = $__componentOriginalce262628e3a8d44dc38fd1f3965181bc; ?>
<?php unset($__componentOriginalce262628e3a8d44dc38fd1f3965181bc); ?>
<?php endif; ?> Log jawaban kuis terbaru</div>
    <table class="tbl">
        <thead>
            <tr>
                <th>Siswa</th><th>Soal (Arab)</th><th>Jawaban siswa</th><th>Referensi</th>
                <th style="text-align:center">Jarak (d)</th><th>Status</th><th style="text-align:center">Poin</th><th>Waktu</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $logJawaban; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($log->session->user->name ?? '-'); ?></td>
                <td style="font-size:16px;direction:rtl"><?php echo e($log->mufrodat->arab ?? '-'); ?></td>
                <td><?php echo e($log->jawaban_siswa ?: '-'); ?></td>
                <td style="color:var(--gray-500)"><?php echo e($log->jawaban_referensi); ?></td>
                <td style="text-align:center;font-weight:700;color:<?php echo e($log->status === 'BENAR' ? 'var(--green)' : ($log->status === 'TYPO' ? 'var(--amber)' : 'var(--red)')); ?>">
                    <?php echo e($log->jarak_levenshtein); ?>

                </td>
                <td><span class="pill <?php echo e($log->status === 'BENAR' ? 'pill-green' : ($log->status === 'TYPO' ? 'pill-amber' : 'pill-red')); ?>"><?php echo e($log->status); ?></span></td>
                <td style="text-align:center;font-weight:700;color:<?php echo e($log->status === 'BENAR' ? 'var(--green)' : ($log->status === 'TYPO' ? 'var(--amber)' : 'var(--red)')); ?>">+<?php echo e($log->poin); ?></td>
                <td style="color:var(--gray-400);font-size:11px"><?php echo e($log->created_at->diffForHumans()); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="pagination"><?php echo e($logJawaban->withQueryString()->links('pagination.custom')); ?></div>
</div>

<?php if($logJawaban->currentPage() > 1): ?>
<script>
    document.getElementById('log-jawaban')?.scrollIntoView({ behavior: 'instant', block: 'start' });
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-murfodat', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\PBKK\mufrodat_ku\resources\views/admin/laporan.blade.php ENDPATH**/ ?>